package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        /*Задание №9
         Сила тяжести на Луне составляет около 1 7% земной. Напишите программу,
         которая вычислила бы ваш вес на Луне.*/

        System.out.print("Ваш вес(кг) = ");
        Scanner scan = new Scanner(System.in);
        double res = scan.nextDouble() / 100 * 17;
        System.out.println("Ваш вес на луне = " + res + " кг");
        System.out.println("");
        System.out.println("");
        /*Задание №10
        Видоизмените программу, созданную в упражнении 1.2, таким образом,
        чтобы она выводила таблицу перевода дюймов в метры. Выведите значения
        длины до 12 футов через каждый дюйм. После каждых 12 дюймов выведите
        пустую строку. (Один метр приблизительно равен 39,37 дюйма.)*/

        double inches , meters , ft ;
        String str;
        int counter;
        counter = 0;
        for ( inches = 1; inches <= 100; inches++) {

            meters = inches * 39.37 ; // преобразование в метры
            str = String.format("%.2f", meters);
            System.out . println ( inches + " дюймам соответ ствует " + str + " метрам.") ;
            counter++;
            if ( counter == 12) {
                System.out.println ("");
                counter = 0;
            }
            for(ft = 1; ft <=12; ft++){
                meters = ft * 39.37 * 12 ; // преобразование в метры
                str = String.format("%.2f", meters);
                System.out . println ( ft + " футам соответ ствует " + str + " метрам.") ;
            }
        }
    }
}